cap_device_A ={
            "platformName": "Android",
            "udid": "ZD2224LD3H",
            "deviceName": "Motorola G40",
            "appPackage": "com.google.android.gm",
            "appActivity": ".ui.MailActivityGmail",
            "automationName": "UiAutomator2",
            "noReset" : True,
            "fullReset" : False,
            "newCommandTimeout": 1200
            }

cap_device_B = {
            "platformName": "Android",
            "udid": "RZ8W2094M7D",
            "deviceName": "Samsung_device",
            "appPackage": "com.google.android.gm",
            "appActivity": ".ui.MailActivityGmail",
            "automationName": "UiAutomator2",
            "noReset" : True,
            "fullReset" : False,
            "newCommandTimeout": 1200
           }

url = "http://localhost:4723/wd/hub"


